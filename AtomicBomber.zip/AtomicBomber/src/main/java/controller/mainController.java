package controller;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import view.MainMenu;
import view.accountMenu;

public class mainController {
    public TextField username;
    public TextField password;

    public void function1(MouseEvent mouseEvent) {

        accountMenu signUpMenu=new accountMenu();
        try {
            signUpMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }


    public void function2(MouseEvent mouseEvent) {
        Platform.exit();
    }
}
