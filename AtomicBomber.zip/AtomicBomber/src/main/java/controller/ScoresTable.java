package controller;

import javafx.scene.input.MouseEvent;
import view.GameMenu;
import view.MainMenu;

import java.io.IOException;

public class ScoresTable {

    public void BackToGameMenu(MouseEvent mouseEvent) {
            GameMenu gameMenu=new GameMenu();
            try {
                gameMenu.start(MainMenu.stage);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

    }
}
