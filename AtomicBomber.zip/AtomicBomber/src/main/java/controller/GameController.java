package controller;

import javafx.scene.control.*;
import javafx.fxml.Initializable;

import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import model.*;
import view.Animation.shootingAttackTankBomb;
import view.Animation.shootingBomb;
import view.Animation.shootingCluster;
import view.Animation.shootingRadioActive;
import view.GameLauncher;
import view.MainMenu;
import view.ScoresTable;
import view.SettingMenu;
import view.profileMenu;

import java.net.URL;
import java.util.ResourceBundle;

public class GameController implements Initializable {
    public ImageView avatarImage;
    public Label usernametext;
    public Button continueGame;
    public Button profile;
    public Button startGame;

    public static void shoot(Pane pane, Jet jet, Game game, boolean haveAngle) {
        Bombs bombs=new Bombs(jet);
        pane.getChildren().add(bombs);
        shootingBomb shootingBomb =new shootingBomb(pane,game,bombs,false);
        shootingBomb.play();
    }
    public static void shootAngle(Pane pane, Jet jet, Game game, boolean haveAngle) {
        Bombs bombs=new Bombs(jet);
        pane.getChildren().add(bombs);
        shootingBomb shootingBomb =new shootingBomb(pane,game,bombs,true);
        shootingBomb.play();
    }

    public static void shootRadio(Pane pane, Jet jet, Game game) {
        RadioActive radioActive=new RadioActive(jet);
        pane.getChildren().add(radioActive);
        int jetIndex=pane.getChildren().indexOf(jet);
        shootingRadioActive shootingRadioActive=new shootingRadioActive(pane,game,radioActive);
        shootingRadioActive.play();
    }
    public static void shootCluster(Pane pane, Jet jet, Game game){
        Cluster cluster=new Cluster(jet);
        pane.getChildren().add(cluster);
        shootingCluster shootingCluster=new shootingCluster(game,pane,cluster);
        shootingCluster.play();
    }
    public static void shootTank(Pane pane,AttackTank attackTank,Game game,Jet jet){
        AttackTankBomb attackTankBomb=new AttackTankBomb(attackTank);
        pane.getChildren().add(attackTankBomb);
        shootingAttackTankBomb shootingAttackTankBomb=new shootingAttackTankBomb(game,pane,attackTankBomb,jet);
        shootingAttackTankBomb.play();
    }

    public void setUsernametext(String username){
        usernametext.setText(username);
    }
    public void setImage(ImageView imageView){
        avatarImage.setImage(imageView.getImage());
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setUsernametext(accountController.usernameCopy);
    }

    public void startGame(MouseEvent mouseEvent) {
        GameLauncher gameLauncher =new GameLauncher(usernametext.getText());
        try {
            gameLauncher.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public void GoToProfile(){
        profileMenu profileMenu=new profileMenu();
        try {
            profileMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void countinueGame(MouseEvent mouseEvent) {

    }

    public void GoToSetting(MouseEvent mouseEvent) {
        SettingMenu settingMenu=new SettingMenu();
        try {
            settingMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void scoreTable(MouseEvent mouseEvent) {
        ScoresTable scoresTable=new ScoresTable();
        try {
            scoresTable.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
