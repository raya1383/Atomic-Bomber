package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import view.MainMenu;
import view.accountMenu;
import view.avatarMenu;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class profileController {
    public TextField newUserName;
    public TextField newPassWord;
    public int flag1=0,flag2=0;

    public void changeUserName(MouseEvent mouseEvent){
        int flag1=0;
        try{
            BufferedReader reader = new BufferedReader(new FileReader("usernames.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(newUserName.getText())) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setHeaderText("خطا!");
                    alert.setContentText("نام کاربری ای که وارد کرده اید قبلا انتخاب شده است");
                    alert.show();
                    flag1 = 1;
                    return;
                }
            }
            reader.close();

        }catch (IOException e) {
            e.printStackTrace();
        }
        if (flag1==0){
            //change old line with new line
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText("به به");
            alert.setContentText("با موفقیت نام کاربریت عوض شد");
            alert.show();
        }

    }
    public void changePass(MouseEvent mouseEvent){
       String oldUsername= accountController.usernameCopy;
       accountController.account.remove(oldUsername);
       accountController.account.put(oldUsername,newPassWord.getText());
        Alert alert =new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText("به به");
        alert.setContentText("با موفقیت رمز عبورت عوض شد");
        alert.show();
    }

    public void goBack(MouseEvent mouseEvent) {
        accountMenu accountMenu=new accountMenu();
        try {
            accountMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteAccount(MouseEvent mouseEvent) {
        accountController.usernames.remove(accountController.usernameCopy);
        accountController.account.remove(accountController.usernameCopy);
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText("ای وای ");
        alert.setContentText("حساب کاربریت حذف شد :( ");
        alert.show();
        accountMenu accountMenu=new accountMenu();
        try {
            accountMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }


    public void goToAvatar(MouseEvent mouseEvent) {
        avatarMenu avatarMenu =new avatarMenu();
        try {
            avatarMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
