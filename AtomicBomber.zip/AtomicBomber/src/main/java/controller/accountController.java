package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import view.MainMenu;
import view.profileMenu;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.*;
public class accountController {
    public static File usernameFile;
    public static FileWriter usernameWriter;

    public static void FileExist() {
        try{
        usernameFile=new File("usernames.txt");
        if (!usernameFile.exists()){
            usernameFile.createNewFile();
        }
        usernameWriter=new FileWriter(usernameFile,true);

        } catch (IOException e) {
                throw new RuntimeException(e);
        }
    }


    public TextField username1;
    public  TextField password1;
    public static String usernameCopy;
    public static String passwordCopy;

    public static ArrayList<String> usernames=new ArrayList<>();
    public static HashMap<String,String> account=new HashMap<>();
    public void signInFunction(MouseEvent mouseEvent) throws IOException {
        FileExist();
        usernameCopy= username1.getText();
        passwordCopy= password1.getText();
         int flag1=0;
        try{
            BufferedReader reader = new BufferedReader(new FileReader("usernames.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(usernameCopy)) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setHeaderText("خطا!");
                alert.setContentText("نام کاربری ای که وارد کرده اید قبلا انتخاب شده است");
                alert.show();
                flag1 = 1;
                return;
                }}
            reader.close();

        }catch (IOException e) {
            e.printStackTrace();
        }
        if (flag1==0) {
            usernameWriter.write(usernameCopy + "\n"+ passwordCopy + "\n");
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText("هورااا");
        alert.setContentText("ثبت نام با موفقیت انجام شد!");
        alert.show();
        GoToProfileMenu();
        usernameWriter.close();
    }

    public void enterFunction(MouseEvent mouseEvent) throws IOException {
        usernameCopy = username1.getText();
        passwordCopy = password1.getText();
        int flag2 = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader("usernames.txt"));
            String line;
            boolean found = false;
            while ((line = reader.readLine()) != null) {
                if (found) {
                    if (line.equals(passwordCopy)) {
                        System.out.println(line);
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setHeaderText("خوش آمدید!");
                        alert.setContentText("ورود با موفقیت انجام شد");
                        alert.show();
                        GoToProfileMenu();
                        return;
                    } else {
                        // Wrong password
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setHeaderText("خطا!");
                        alert.setContentText("رمز عبور اشتباه است");
                        alert.show();
                        return;
                    }
                }
                if (line.contains(usernameCopy)) {
                    found = true;
                }
            }
            // Username not found
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText("خطا!");
            alert.setContentText("نام کاربری اشتباه است");
            alert.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guestFunction(MouseEvent mouseEvent) throws IOException {
        FileExist();
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText("هوراااا");
        alert.setContentText("به عنوان مهمان به بازی وارد شدید");
        usernameCopy="\nمهمان";
        alert.show();
        GoToProfileMenu();
        usernameWriter.write(usernameCopy);
        usernameWriter.close();
    }
    public void GoToProfileMenu(){
        profileMenu profileMenu= new profileMenu();
        try {
            profileMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }



}
