package controller;

import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import view.Animation.TankAnimation;
import view.Animation.TruckAnimation;
import view.GameLauncher;
import view.GameMenu;
import view.MainMenu;

import java.io.IOException;

public class SettingController {


    public TextField right;
    public TextField left;
    public TextField up;
    public TextField down;
    public Button controllKeys;
    public Button BackToGameMenu;
    public CheckBox checkBox1;
    public CheckBox checkBox2;
    public CheckBox checkBox3;
    public static int flag=0;
    public static CheckBox sound;
    public static boolean isMuted;

    public void BackToGameMenu(MouseEvent mouseEvent) {
        GameMenu gameMenu=new GameMenu();
        try {
            gameMenu.start(MainMenu.stage);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void changeControllKeys(MouseEvent mouseEvent) {
        right.setVisible(true);
        left.setVisible(true);
        up.setVisible(true);
        down.setVisible(true);
        KeyCode rightKeyCode=KeyCode.getKeyCode(right.getText());
        KeyCode leftKeyCode=KeyCode.getKeyCode(left.getText());
        KeyCode upKeyCode=KeyCode.getKeyCode(up.getText());
        KeyCode downKeyCode=KeyCode.getKeyCode(down.getText());
        GameLauncher.changeKey(rightKeyCode,leftKeyCode,upKeyCode,downKeyCode);
    }
    TankAnimation tankAnimation;
    double newSpeed=1.5;
    public void changeGameLevel(MouseEvent mouseEvent) {
        flag=1;
        checkBox1.setVisible(true);
        checkBox2.setVisible(true);
        checkBox3.setVisible(true);
        if (checkBox1.isSelected()){
             TankAnimation.speed=1.5;
        }else if (checkBox2.isSelected()){
            TankAnimation.speed=3;
        }else if (checkBox3.isSelected()){
            TankAnimation.speed=4.5;

        }

    }
    public  static void soundMute(){
        if (sound.isSelected()){
           isMuted=true;
        }
    }

}
