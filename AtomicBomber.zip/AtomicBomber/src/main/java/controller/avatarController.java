package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.fxml.Initializable;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import view.GameLauncher;
import view.GameMenu;
import view.MainMenu;
import view.profileMenu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

public class avatarController implements Initializable {
    @FXML
    public ImageView imageView;
    public MenuButton menuButtonId;
    public MenuItem choice2;
    public MenuItem choice1;
    public Circle setting;
    public ImageView image2;
    public TextField numberOfImage;
    public Button button2;
    public MenuItem choice3;
    @FXML
    private Label welcomeText;
     public String imageUrl;

    String username= accountController.usernameCopy;
    public void updateWelcome(String username) {

        welcomeText.setText(username+ " خوش آمدی");

    }
    public void selectRandomImage() {
        Random random = new Random();
        int imageNumber = random.nextInt(7) + 1;
        imageUrl = String.format("/FXML/AvatarImages/%d.png", imageNumber);
        InputStream stream = getClass().getResourceAsStream(imageUrl);
        Image image = new Image(stream);
        imageView.setImage(image);

    }


    public void changeImage(MouseEvent mouseEvent) {
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("ما خودمون این تصویر رو برای آواتارت انتخاب کردیم. اگه میخوای عوضش کنی از تنظیمات این کارو انجام بده");
        alert.setHeaderText("سلام");
        alert.setTitle("آواتار");
        alert.show();
    }

    public void showChangeOptions(MouseEvent mouseEvent) {
        menuButtonId.setVisible(true);
    }

    public void chooseFromGameImages(ActionEvent actionEvent) {
        button2.setVisible(true);
        numberOfImage.setVisible(true);
        String imageUrl2 = "/FXML/chooseImage/choose.png";
        InputStream stream = getClass().getResourceAsStream(imageUrl2);
        Image image = new Image(stream);
        image2.setImage(image);

    }

    public void chooseAnotherImageFile(ActionEvent actionEvent) {

            FileChooser fileChooser=new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image File" , "*.png" , "*.jpg" , "*.jpeg"));
            File selectedFile=fileChooser.showOpenDialog(null);
            if (selectedFile != null){
                Image image=new Image(selectedFile.toURI().toString());
                imageView.setImage(image);
            }

    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        updateWelcome(username);
        selectRandomImage();
    }

    public void changeAvatarImage(MouseEvent mouseEvent) {
       int imageNumber= Integer.parseInt(numberOfImage.getText());
        String imageUrl = String.format("/FXML/AvatarImages/%d.png", imageNumber);
        InputStream stream = getClass().getResourceAsStream(imageUrl);
        Image image = new Image(stream);
        imageView.setImage(image);
        button2.setVisible(false);
        numberOfImage.setVisible(false);
        image2.setVisible(false);
    }

    public void imageViewDragDropped(DragEvent dragEvent) throws FileNotFoundException {
        Dragboard dragboard = dragEvent.getDragboard();
        if (dragboard.hasImage() || dragboard.hasFiles()){
            imageView.setImage(new Image(new FileInputStream(dragboard.getFiles().get(0))));
        }
    }

    public void imageViewDragOver(DragEvent dragEvent) {
        Dragboard dragboard = dragEvent.getDragboard();
        if (dragboard.hasImage()|| dragboard.hasFiles()){
            dragEvent.acceptTransferModes(TransferMode.COPY);
        }

        dragEvent.consume();
    }

    public void goToGameMenu(MouseEvent mouseEvent) {
            GameMenu gameMenu =new GameMenu();
            try {
                gameMenu.start(MainMenu.stage);
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
    public void goToProfileMenu(MouseEvent mouseEvent) {
        profileMenu profileMenu =new profileMenu();
        try {
            profileMenu.start(MainMenu.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
