package view.Animation;


import javafx.animation.Transition;
import javafx.scene.Group;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.*;
public class BuildingExplosionAnimation extends Transition{
    private final Building building;
    private final Pane pane;
    private final Group buildings;

    public BuildingExplosionAnimation(Building building, Pane pane, Group buildings){
        this.building=building;
        this.pane=pane;
        this.buildings=buildings;
        this.setCycleCount(1);
        this.setCycleDuration(Duration.millis(1000));
    }

    @Override
    protected void interpolate(double v) {

    }
}
