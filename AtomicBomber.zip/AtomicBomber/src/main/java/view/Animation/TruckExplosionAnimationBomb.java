package view.Animation;


import javafx.animation.Transition;
import javafx.scene.Group;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.*;
public class TruckExplosionAnimationBomb extends Transition{
    private final Truck truck;
    private final Pane pane;
    private final Group trucks;

    public TruckExplosionAnimationBomb(Truck truck, Pane pane, Group trucks){
        this.truck=truck;
        this.pane=pane;
        this.trucks=trucks;
        this.setCycleCount(1);
        this.setCycleDuration(Duration.millis(1000));

    }

    @Override
    protected void interpolate(double v) {

    }




}


