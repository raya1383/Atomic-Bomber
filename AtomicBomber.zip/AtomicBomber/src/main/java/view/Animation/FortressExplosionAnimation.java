package view.Animation;


import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.*;
public class FortressExplosionAnimation extends Transition{
    private final Fortress fortress;
    private final Pane pane;
    private final Group fortresses;

    public FortressExplosionAnimation(Fortress fortress, Pane pane, Group fortresses){
        this.fortress=fortress;
        this.pane=pane;
        this.fortresses=fortresses;
        this.setCycleCount(1);
        this.setCycleDuration(Duration.millis(1000));
    }

    @Override
    protected void interpolate(double v) {
        double x=0.0263;
        int number=1;
        if(v>=0 && v<x) number=1;
        else if (v>=x && v<2*x) number=2;
        else if (v>=2*x && v<3*x) number=3;
        else if (v>=3*x && v<4*x) number=4;
        else if (v>=4*x && v<5*x) number=5;
        else if (v>=5*x && v<6*x) number=6;
        else if (v>=6*x && v<7*x) number=7;
        else if (v>=7*x && v<8*x) number=8;
        else if (v>=8*x && v<9*x) number=9;
        else if (v>=9*x && v<10*x) number=10;
        else if (v>=10*x && v<11*x) number=11;
        else if (v>=11*x && v<12*x) number=12;
        else if (v>=12*x && v<13*x) number=13;
        else if (v>=13*x && v<14*x) number=14;
        else if (v>=14*x && v<15*x) number=15;
        else if (v>=15*x && v<16*x) number=16;
        else if (v>=16*x && v<17*x) number=17;
        else if (v>=17*x && v<18*x) number=18;
        else if (v>=18*x && v<19*x) number=19;
        else if (v>=19*x && v<20*x) number=20;
        else if (v>=20*x && v<21*x) number=21;
        else if (v>=21*x && v<22*x) number=22;
        else if (v>=22*x && v<23*x) number=23;
        else if (v>=23*x && v<24*x) number=24;
        else if (v>=24*x && v<25*x) number=25;
        else if (v>=25*x && v<26*x) number=26;
        else if (v>=26*x && v<27*x) number=27;
        else if (v>=27*x && v<28*x) number=28;
        else if (v>=28*x && v<29*x) number=29;
        else if (v>=29*x && v<30*x) number=30;
        else if (v>=30*x && v<31*x) number=31;
        else if (v>=31*x && v<32*x) number=32;
        else if (v>=32*x && v<33*x) number=33;
        else if (v>=33*x && v<34*x) number=34;
        else if (v>=34*x && v<35*x) number=35;
        else if (v>=35*x && v<36*x) number=36;
        else if (v>=36*x && v<37*x) number=37;
        else if (v>=37*x && v<38*x) number=38;

        fortress.setFill(new ImagePattern(new Image
                (TruckAnimation.class.getResource("/FXML/Explosion/"+number+".png").toString())));

        this.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                fortresses.getChildren().remove(fortress);
            }
        });



    }
}

