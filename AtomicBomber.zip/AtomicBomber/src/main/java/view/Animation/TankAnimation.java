package view.Animation;

import controller.SettingController;
import javafx.animation.Transition;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.Game;
import model.Tank;
import view.GameLauncher;


public class TankAnimation extends Transition {
    private final Game game;
    private final Pane pane;
    private final Tank tank;
    public static double speed=1.5 ;
    private final int duration = 100;


    public TankAnimation(Pane pane, Game game, Tank tank) {
        this.pane = pane;
        this.game = game;
        this.tank=tank;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate (double v) {
        double x = tank.getX() + speed;

        if (x >= game.WIDTH) {
            pane.getChildren().remove(tank);
            this.stop();
        }

        tank.setX(x);
    }
}

