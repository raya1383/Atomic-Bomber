package view.Animation;


import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.*;
public class TankExplosionAnimationCluster extends Transition{
    private final Tank tank;
    private final Pane pane;
    private final Group tanks;

    public TankExplosionAnimationCluster(Tank tank, Pane pane, Group tanks){
        this.tank=tank;
        this.pane=pane;
        this.tanks=tanks;
        this.setCycleCount(1);
        this.setCycleDuration(Duration.millis(1000));
    }

    @Override
    protected void interpolate(double v) {
        int number=1;
        if (v>=0 && v<0.25)number=1;
        else if (v>=0.25 && v<0.5) number=2;
        else if (v>=0.5 && v<0.75) number=3;
        else if(v>=0.75 && v<=1)   number=4;
        tank.setFill(new ImagePattern(new Image
                (TruckAnimation.class.getResource("/FXML/images/fire-"+number+".png").toString())));

        this.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                tanks.getChildren().remove(tank);
            }

        });
    }
}

