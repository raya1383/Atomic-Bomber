package view.Animation;

import controller.GameController;
import controller.SettingController;
import javafx.animation.Transition;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.AttackTank;
import model.Game;
import model.Jet;
import model.Tank;
import view.GameLauncher;


public class AttackTankAnimation extends Transition {
    private final Game game;
    private final Pane pane;
    private final Jet jet;
    private final AttackTank attackTank;
    public static double speed=1.5 ;
    private final int duration = 100;


    public AttackTankAnimation(Pane pane, Game game, AttackTank attackTank,Jet jet) {
        this.pane = pane;
        this.game = game;
        this.attackTank=attackTank;
        this.jet=jet;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate (double v) {
        double x = attackTank.getX() + speed;
        if (jet.getX()>=attackTank.getX()-50 && jet.getX()<=attackTank.getX()+50){
            GameController.shootTank(pane,attackTank,game,jet);
        }

        if (x >= game.WIDTH) {
            pane.getChildren().remove(attackTank);
            this.stop();
        }

        attackTank.setX(x);
    }
}
