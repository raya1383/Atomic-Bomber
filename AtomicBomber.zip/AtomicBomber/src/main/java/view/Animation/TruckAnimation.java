package view.Animation;

import javafx.animation.Transition;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import model.Game;
import model.Truck;
import view.GameLauncher;


public class TruckAnimation extends Transition {
        private final Game game;
        private final Pane pane;
        private final Truck truck;
        private  double speed = 2;
        private final int duration = 100;


        public TruckAnimation(Pane pane, Game game, Truck truck) {
            this.pane = pane;
            this.game = game;
            this.truck=truck;
            this.setCycleDuration(Duration.millis(duration));
            this.setCycleCount(-1);
        }

        @Override
        protected void interpolate (double v) {
            double x = truck.getX() + speed;

           if (x >= game.WIDTH) {
                pane.getChildren().remove(truck);
                this.stop();
            }

            truck.setX(x);
        }
}
