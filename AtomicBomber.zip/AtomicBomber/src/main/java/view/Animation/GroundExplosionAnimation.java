package view.Animation;


import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.*;
public class GroundExplosionAnimation extends Transition {
    private final Ground ground;
    private final Pane pane;
    private final Group grounds;

    public GroundExplosionAnimation(Ground ground,Pane pane, Group grounds) {

        this.pane = pane;
        this.ground=ground;
        this.grounds=grounds;
        this.setCycleCount(1);
        this.setCycleDuration(Duration.millis(1000));

    }

    @Override
    protected void interpolate(double v) {
        double x=0.25;
        int number=1;
        if(v>=0 && v<x) number=1;
        else if (v>=x && v<2*x) number=2;
        else if (v>=2*x && v<3*x) number=3;
        else if (v>=3*x && v<4*x) number=4;
        ground.setFill(new ImagePattern(new Image
                (TruckAnimation.class.getResource("/FXML/images/fire-"+number+".png").toString())));
        System.out.println("h");

        this.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                grounds.getChildren().remove(ground);
            }
        });
    }
}
