package view.Animation;

import controller.ApplicationController;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.*;
import view.GameLauncher;

public class shootingBomb extends Transition {
    private final Game game;
    private final Pane pane;
    private Bombs bombs;
    private Timeline createGround;
    private final double speed = 4;
    private final int duration = 100;
    boolean hasExploded=false;
    boolean haveAngle=false;

    public shootingBomb(Pane pane, Game game, Bombs bombs,boolean haveAngle) {
        this.pane = pane;
        this.game = game;
        this.bombs = bombs;
        this.haveAngle=haveAngle;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);

    }

    @Override
    protected void interpolate (double v) {
        int flag=0;
        double y=0;
        if (!haveAngle){
          y = bombs.getY() + speed;
        }else{
            double angle=Math.toRadians(45);
            double x= bombs.getX()+speed*Math.cos(angle);
            y=bombs.getY()+speed*Math.sin(angle);
            bombs.setX(x);
        }

        for(Node child:game.Tank.getChildren()){
            Tank tank=(Tank) child;
            if (tank.getBoundsInParent().intersects(bombs.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                if (!GameLauncher.GameIsMuted){
                Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                MediaPlayer mediaPlayer=new MediaPlayer(media);
                mediaPlayer.setAutoPlay(true);}

                if (tank.isHit) continue;
                tank.isHit = true;
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                tank.getTankAnimation().stop();
                TankExplosionAnimation tankExplosionAnimation = new TankExplosionAnimation(tank, pane, game.Tank);
                game.animations.add(tankExplosionAnimation);
                tankExplosionAnimation.play();

                pane.getChildren().remove(bombs);
                this.stop();
                break;
            }


        }
        for(Node child:game.AttackTank.getChildren()){
            AttackTank attackTank=(AttackTank) child;
            if (attackTank.getBoundsInParent().intersects(bombs.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}

                if (attackTank.isHit) continue;
                attackTank.isHit = true;
                game.score += 250;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                attackTank.getAttackTankAnimation().stop();
                AttackTankExplosionAnimation attackTankExplosionAnimation
                        = new AttackTankExplosionAnimation(attackTank, pane, game.AttackTank);
                game.animations.add(attackTankExplosionAnimation);
                attackTankExplosionAnimation.play();

                pane.getChildren().remove(bombs);
                this.stop();
                break;
            }


        }

        for(Node child:game.Fortress.getChildren()){
            Fortress fortress=(Fortress) child;
            if (fortress.getBoundsInParent().intersects(bombs.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                GameLauncher.NumberOfCluster++;
                GameLauncher.setCluster(GameLauncher.cluster, String.valueOf(GameLauncher.NumberOfCluster));


                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}

                if (fortress.isHit) continue;
                fortress.isHit = true;
                game.score += 50;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                FortressExplosionAnimation fortressExplosionAnimation=new FortressExplosionAnimation(fortress
                ,pane,game.Fortress);
                game.animations.add(fortressExplosionAnimation);
                fortressExplosionAnimation.play();

                pane.getChildren().remove(bombs);
                this.stop();
                break;
            }
        }

        for(Node child:game.Tree.getChildren()) {
            Tree tree = (Tree) child;
            if (tree.getBoundsInParent().intersects(bombs.getBoundsInParent())) {
                GameLauncher.succesfullShooting++;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}

                if (tree.isHit) continue;
                tree.isHit = true;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                game.Tree.getChildren().remove(tree);
                pane.getChildren().remove(bombs);
                this.stop();
                break;
            }
        }


        for(Node child:game.Truck.getChildren()) {
            Truck truck = (Truck) child;
            if (truck.getBoundsInParent().intersects(bombs.getBoundsInParent())) {
                GameLauncher.succesfullShooting++;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                if (truck.isHit) continue;
                truck.isHit = true;
                game.score+=150;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                truck.getTruckAnimation().stop();
                game.Truck.getChildren().remove(truck);
                pane.getChildren().remove(bombs);
                this.stop();
                break;
            }
        }

        for(Node child:game.Building.getChildren()) {
            Building building = (Building) child;
            if (building.getBoundsInParent().intersects(bombs.getBoundsInParent())) {
                GameLauncher.succesfullShooting++;
                GameLauncher.NumberOfRadioActive++;
                GameLauncher.setNumberRadio(GameLauncher.radioActive, String.valueOf(GameLauncher.NumberOfRadioActive));
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}

                if (building.isHit) continue;
                building.isHit = true;
                game.score+=100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                game.Building.getChildren().remove(building);
                pane.getChildren().remove(bombs);
                this.stop();
                break;

            }
        }
        if (y>=470){
            ImageView imageView=new ImageView(new Image(String.valueOf(GameLauncher.class.getResource("/FXML/Explosion/33.png"))));
            imageView.setX(bombs.getX());
            imageView.setY(470);
            imageView.setFitHeight(30);
            imageView.setFitWidth(30);
            pane.getChildren().add(imageView);
            hasExploded=true;
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
                pane.getChildren().remove(imageView);}));
            timeline.play();
        }



       if (y >=500) {
            pane.getChildren().remove(bombs);
            this.stop();
        }

        bombs.setY(y);
    }

}
