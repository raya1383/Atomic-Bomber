package view.Animation;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import model.*;
import view.GameLauncher;

public class shootingCluster extends Transition {

    public final Game game;
    public final Pane pane;
    public final int speed =4;
    public final int duration=100;
    public final Cluster cluster;

    public shootingCluster(Game game,Pane pane,Cluster cluster){
        this.game=game;
        this.pane=pane;
        this.cluster=cluster;
        setCycleDuration(Duration.millis(1000));
        setCycleCount(-1);
    }

    int flag=0;

    @Override
    protected void interpolate(double v) {
       double y=speed+cluster.getY();

       for(Node child: game.Tree.getChildren()){
           Tree tree=(Tree) child;
           if (tree.getBoundsInParent().intersects(cluster.getBoundsInParent())){
               GameLauncher.succesfullShooting++;
               if (!GameLauncher.GameIsMuted){
                   Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                   MediaPlayer mediaPlayer=new MediaPlayer(media);
                   mediaPlayer.setAutoPlay(true);}
               game.score += 0;
               GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
               if(tree.isHit)continue;;
               tree.isHit=true;
               TreeExplosionAnimation treeExplosionAnimation=new TreeExplosionAnimation(tree,pane,game.Tree);
               game.animations.add(treeExplosionAnimation);
               treeExplosionAnimation.play();

               pane.getChildren().remove(cluster);
               this.stop();
               break;
           }
       }
        for(Node child: game.Truck.getChildren()){
            Truck truck=(Truck) child;
            if (truck.getBoundsInParent().intersects(cluster.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                flag=1;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 120;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(truck.isHit)continue;;
                truck.isHit=true;
                TruckExplosionAnimationCluster truckExplosionAnimationCluster=new TruckExplosionAnimationCluster(truck,pane,game.Truck);
                game.animations.add(truckExplosionAnimationCluster);
                truckExplosionAnimationCluster.play();

                pane.getChildren().remove(cluster);
                this.stop();
                break;
            }
        }
        for(Node child: game.Fortress.getChildren()){
            Fortress fortress=(Fortress) child;
            if (fortress.getBoundsInParent().intersects(cluster.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                flag=1;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(fortress.isHit)continue;;
                fortress.isHit=true;
                FortressExplosionAnimationCluster fortressExplosionAnimationCluster
                        =new FortressExplosionAnimationCluster(fortress,pane,game.Fortress);
                game.animations.add(fortressExplosionAnimationCluster);
                fortressExplosionAnimationCluster.play();

                pane.getChildren().remove(cluster);
                this.stop();
                break;
            }
        }
        for(Node child: game.Building.getChildren()){
            Building building=(Building) child;
            if (building.getBoundsInParent().intersects(cluster.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                flag=1;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(building.isHit)continue;;
                building.isHit=true;
                BuildingExplosionAnimationCluster buildingExplosionAnimationCluster
                        =new BuildingExplosionAnimationCluster(building,pane,game.Building);
                game.animations.add(buildingExplosionAnimationCluster);
                buildingExplosionAnimationCluster.play();

                pane.getChildren().remove(cluster);
                this.stop();
                break;
            }
        }
        for(Node child: game.Tank.getChildren()){
            Tank tank=(Tank) child;
            if (tank.getBoundsInParent().intersects(cluster.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                flag=1;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(tank.isHit)continue;;
                tank.isHit=true;
                TankExplosionAnimationCluster tankExplosionAnimationCluster
                        =new TankExplosionAnimationCluster(tank,pane,game.Tank);
                game.animations.add(tankExplosionAnimationCluster);
                tankExplosionAnimationCluster.play();

                pane.getChildren().remove(cluster);
                this.stop();
                break;
            }
        }
        for(Node child:game.AttackTank.getChildren()){
            AttackTank attackTank=(AttackTank) child;
            if (attackTank.getBoundsInParent().intersects(cluster.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}

                if (attackTank.isHit) continue;
                attackTank.isHit = true;
                game.score += 250;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                attackTank.getAttackTankAnimation().stop();
                AttackTankExplosionAnimation attackTankExplosionAnimation
                        = new AttackTankExplosionAnimation(attackTank, pane, game.AttackTank);
                game.animations.add(attackTankExplosionAnimation);
                attackTankExplosionAnimation.play();

                pane.getChildren().remove(cluster);
                this.stop();
                break;
            }


        }
        if (y>=470){
            ImageView imageView=new ImageView(new Image(String.valueOf(GameLauncher.class.getResource("/FXML/images/fire-1.png"))));
            imageView.setX(cluster.getX());
            imageView.setY(470);
            imageView.setFitHeight(30);
            imageView.setFitWidth(30);
            pane.getChildren().add(imageView);
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
                pane.getChildren().remove(imageView);}));
            timeline.play();
        }



       if (y>=500){
           pane.getChildren().remove(cluster);
           this.stop();
       }

       cluster.setY(y);

    }
}
