package view.Animation;


import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.*;
public class TankExplosionRadioActive extends Transition{
    private final Tank tank;
    private final Pane pane;
    private final Group Tanks;

    public TankExplosionRadioActive(Tank tank, Pane pane, Group tanks){
        this.tank=tank;
        this.pane=pane;
        this.Tanks=tanks;
        this.setCycleCount(1);
        this.setCycleDuration(Duration.millis(1000));
    }

    @Override
    protected void interpolate(double v) {
        int number=1;
        if (v>=0 && v<0.125)number=1;
        else if (v>=0.125 && v<0.25) number=2;
        else if (v>=0.25 && v<0.375) number=3;
        else if(v>=0.375 && v<0.5)   number=4;
        else if(v>=0.5 && v<0.625)   number=5;
        else if(v>=0.625 && v<0.75)   number=6;
        else if(v>=0.75 && v<0.875)   number=7;
        else if(v>=0.875 && v<=1)   number=8;
        tank.setFill(new ImagePattern(new Image
                (TruckAnimation.class.getResource("/FXML/images/radioActive-"+number+".png").toString())));

        this.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Tanks.getChildren().remove(tank);
            }

        });
    }
}
