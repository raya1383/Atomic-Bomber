package view.Animation;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import model.*;
import view.GameLauncher;

public class shootingRadioActive extends Transition {
    private final Game game;
    private final Pane pane;
    private final RadioActive radioActive;
    private final double speed = 4;
    private final int duration = 100;

    public shootingRadioActive(Pane pane, Game game, RadioActive radioActive) {
        this.pane = pane;
        this.game = game;
        this.radioActive=radioActive;
        this.setCycleDuration(Duration.millis(duration));
        this.setCycleCount(-1);
    }

    @Override
    protected void interpolate (double v) {
        double y = radioActive.getY() + speed;
        for(Node child: game.Tree.getChildren()){
            Tree tree=(Tree) child;
            if (tree.getBoundsInParent().intersects(radioActive.getBoundsInParent())){
                GameLauncher.progressBar.setProgress(GameLauncher.progressBar.getProgress()+0.2);
                if (GameLauncher.progressBar.getProgress()==1){
                    GameLauncher.haveIce=true;
                    GameLauncher.progressBar.setProgress(0);

                }

                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 0;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(tree.isHit)continue;;
                tree.isHit=true;
                TreeExplosionRadioActive treeExplosionRadioActive=
                        new TreeExplosionRadioActive(tree,pane,game.Tree);
                game.animations.add(treeExplosionRadioActive);
                treeExplosionRadioActive.play();

                pane.getChildren().remove(radioActive);
                this.stop();
                break;
            }
        }
        for(Node child: game.Truck.getChildren()){

            Truck truck=(Truck) child;
            if (truck.getBoundsInParent().intersects(radioActive.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                GameLauncher.progressBar.setProgress(GameLauncher.progressBar.getProgress()+0.2);
                if (GameLauncher.progressBar.getProgress()==1){
                    GameLauncher.haveIce=true;
                    GameLauncher.progressBar.setProgress(0);

                }
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 120;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(truck.isHit)continue;;
                truck.isHit=true;
                TruckExplosionRadioActive truckExplosionRadioActive=
                        new TruckExplosionRadioActive(truck,pane,game.Truck);
                game.animations.add(truckExplosionRadioActive);
                truckExplosionRadioActive.play();

                pane.getChildren().remove(radioActive);
                this.stop();
                break;
            }
        }
        for(Node child: game.Fortress.getChildren()){
            Fortress fortress=(Fortress) child;
            if (fortress.getBoundsInParent().intersects(radioActive.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                GameLauncher.progressBar.setProgress(GameLauncher.progressBar.getProgress()+0.2);
                if (GameLauncher.progressBar.getProgress()==1){
                    GameLauncher.haveIce=true;
                    GameLauncher.progressBar.setProgress(0);

                }
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(fortress.isHit)continue;;
                fortress.isHit=true;
                FortressExplosionRadioActive fortressExplosionRadioActive
                        =new FortressExplosionRadioActive(fortress,pane,game.Fortress);
                game.animations.add(fortressExplosionRadioActive);
                fortressExplosionRadioActive.play();

                pane.getChildren().remove(radioActive);
                this.stop();
                break;
            }
        }
        for(Node child: game.Building.getChildren()){
            Building building=(Building) child;
            if (building.getBoundsInParent().intersects(radioActive.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                GameLauncher.progressBar.setProgress(GameLauncher.progressBar.getProgress()+0.2);
                if (GameLauncher.progressBar.getProgress()==1){
                    GameLauncher.haveIce=true;
                    GameLauncher.progressBar.setProgress(0);

                }
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(building.isHit)continue;;
                building.isHit=true;
                BuildingExplosionRadioActive buildingExplosionRadioActive
                        =new BuildingExplosionRadioActive(building,pane,game.Building);
                game.animations.add(buildingExplosionRadioActive);
                buildingExplosionRadioActive.play();

                pane.getChildren().remove(radioActive);
                this.stop();
                break;
            }
        }
        for(Node child: game.Tank.getChildren()){
            Tank tank=(Tank) child;
            if (tank.getBoundsInParent().intersects(radioActive.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                GameLauncher.progressBar.setProgress(GameLauncher.progressBar.getProgress()+0.2);
                if (GameLauncher.progressBar.getProgress()==1){
                    GameLauncher.haveIce=true;
                    GameLauncher.progressBar.setProgress(0);

                }
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}
                game.score += 100;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                if(tank.isHit)continue;;
                tank.isHit=true;
                TankExplosionRadioActive tankExplosionRadioActive
                        =new TankExplosionRadioActive(tank,pane,game.Tank);
                game.animations.add(tankExplosionRadioActive);
                tankExplosionRadioActive.play();

                pane.getChildren().remove(radioActive);
                this.stop();
                break;
            }
        }
        for(Node child:game.AttackTank.getChildren()){
            AttackTank attackTank=(AttackTank) child;
            if (attackTank.getBoundsInParent().intersects(radioActive.getBoundsInParent())){
                GameLauncher.succesfullShooting++;
                if (!GameLauncher.GameIsMuted){
                    Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
                    MediaPlayer mediaPlayer=new MediaPlayer(media);
                    mediaPlayer.setAutoPlay(true);}

                if (attackTank.isHit) continue;
                attackTank.isHit = true;
                game.score += 250;
                GameLauncher.setScoreLabel(GameLauncher.label,String.valueOf(game.score));
                attackTank.getAttackTankAnimation().stop();
                AttackTankExplosionAnimation attackTankExplosionAnimation
                        = new AttackTankExplosionAnimation(attackTank, pane, game.AttackTank);
                game.animations.add(attackTankExplosionAnimation);
                attackTankExplosionAnimation.play();

                pane.getChildren().remove(radioActive);
                this.stop();
                break;
            }


        }
        if (y>=470){

            ImageView imageView=new ImageView(new Image(String.valueOf(GameLauncher.class.getResource("/FXML/images/radioActive-5.png"))));
            imageView.setX(radioActive.getX());
            imageView.setY(470);
            imageView.setFitHeight(30);
            imageView.setFitWidth(30);
            pane.getChildren().add(imageView);
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
                pane.getChildren().remove(imageView);}));
            timeline.play();
        }


        if (y >=500) {
            pane.getChildren().remove(radioActive);
            this.stop();
        }

        radioActive.setY(y);
    }
}
