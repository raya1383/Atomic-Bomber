package view.Animation;


import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.util.Duration;
import model.*;
public class TreeExplosionAnimation extends Transition{
    private final Tree tree;
    private final Pane pane;
    private final Group trees;

   public TreeExplosionAnimation(Tree tree, Pane pane, Group trees){
       this.tree=tree;
       this.pane=pane;
       this.trees=trees;
       this.setCycleCount(1);
       this.setCycleDuration(Duration.millis(1000));
   }

    @Override
    protected void interpolate(double v) {
        int number=1;
        if (v>=0 && v<0.25)number=1;
        else if (v>=0.25 && v<0.5) number=2;
        else if (v>=0.5 && v<0.75) number=3;
        else if(v>=0.75 && v<=1)   number=4;
        tree.setFill(new ImagePattern(new Image
                (TruckAnimation.class.getResource("/FXML/images/fire-"+number+".png").toString())));

        this.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                trees.getChildren().remove(tree);
            }

        });
    }
}
