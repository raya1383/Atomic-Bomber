package view.Animation;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.*;
import view.GameLauncher;

public class shootingAttackTankBomb extends Transition {

    public final Game game;
    public final Pane pane;
    public final Jet jet;
    public final int speed =4;
    public final int duration=100;
    public final AttackTankBomb attackTankBomb;

    public shootingAttackTankBomb(Game game,Pane pane,AttackTankBomb attackTankBomb, Jet jet){
        this.game=game;
        this.pane=pane;
        this.attackTankBomb=attackTankBomb;
        this.jet=jet;
        setCycleDuration(Duration.millis(1000));
        setCycleCount(-1);
    }

    int flag=0;

    @Override
    protected void interpolate(double v) {
        double y=attackTankBomb.getY()-speed;
        if (jet.getBoundsInParent().intersects(attackTankBomb.getBoundsInParent())){
            GameLauncher.jetNumber--;
            if (GameLauncher.jetNumber==0){
                GameLauncher.gameOver=true;
                GameLauncher.GameOver();
            }
            if (!GameLauncher.GameIsMuted){
            Media media=new Media(getClass().getResource("/Media/explosion.wav").toString());
            MediaPlayer mediaPlayer=new MediaPlayer(media);
            mediaPlayer.setAutoPlay(true);}

            JetExplosionAnimation jetExplosionAnimation=new JetExplosionAnimation(jet,pane,game.Jet);
            game.animations.add(jetExplosionAnimation);
            jetExplosionAnimation.play();
            pane.getChildren().remove(attackTankBomb);
            this.stop();


        }



        if (y<=0){
            pane.getChildren().remove(attackTankBomb);
            this.stop();
        }
        attackTankBomb.setY(y);

    }
}
