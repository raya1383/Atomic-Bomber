package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.URL;

public class MainMenu extends Application {
    public static Stage stage;
    public static void main(String[] args) {
       launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Atomic Bomber");
        Image icon=new Image(String.valueOf(getClass().getResource("/FXML/images/icon.jpg")));
        stage.getIcons().add(icon);
        MainMenu.stage=stage;
        URL url= MainMenu.class.getResource("/FXML/main.fxml");
        BorderPane root= FXMLLoader.load(url);
        root.setBackground(new Background(new BackgroundFill(Color.rgb(123,104,238), CornerRadii.EMPTY,null)));
        Scene scene =new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}