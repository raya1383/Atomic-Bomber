package view;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Game;

import java.io.IOException;
import java.net.URL;

public class GameMenu {
    public void start(Stage stage) throws IOException {
        MainMenu.stage=stage;
        URL url= MainMenu.class.getResource("/FXML/Game.fxml");
        BorderPane root= FXMLLoader.load(url);
        root.setBackground(new Background(new BackgroundFill(Color.rgb(123,104,238), CornerRadii.EMPTY,null)));
        Scene scene =new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
