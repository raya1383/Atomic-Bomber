package view;

import controller.ApplicationController;
import controller.GameController;
import controller.SettingController;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;
import model.*;
import view.Animation.AttackTankAnimation;
import view.Animation.TankAnimation;
import view.Animation.TruckAnimation;
import javafx.scene.paint.Color;

import java.io.IOException;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import static javafx.scene.input.KeyCode.*;

public class GameLauncher extends Application {
    static int n=0,m=0,p=0,q=0;
    public Jet jet;
    public Timeline createTruckWave1;
    public Timeline createTruckWave2;
    public Timeline createTankWave2;
    public Timeline createTank;
    public Timeline createTree;
    public Timeline createBuilding;
    private Timeline createFortress;
    public Timeline createAttackTank;
    public static int NumberOfRadioActive=0;
    public static int NumberOfCluster=0;
    public final double HEIGHT=500;
    public final double WIDTH=800;
    public static Pane pane;
    public static  Game game;
    public int flag=0,flag1=0,flag2=0;
    private static KeyCode RightKey=S;
    private static KeyCode LeftKey=A;
    private static KeyCode UpKey=W;
    private static KeyCode DownKey=Z;
    public static boolean haveIce=false;
    public static boolean canGoToWave2=false;
    public static boolean gameOver=false;
    private Tank tank;
    private Truck truck;
    private AttackTank attackTank;
    private static MediaPlayer currentMediaPlayer;
    public int truckCount=0;
    public int tankCount=0;
    public int AttackTankCount=0;
    public static ProgressBar progressBar = new ProgressBar(0);
    public static int Wave=1;
    public static int succesfullShooting;
    public static int AllShooting;
    public static boolean Wave1Finish1=false;
    public static boolean Wave1Finish2=false;
    public static boolean Wave2Finish1=false;
    public static boolean Wave2Finish2=false;
    public static boolean Wave2Finish3=false;
    public static boolean GameIsMuted= SettingController.isMuted;
    public static int jetNumber=3;

   public int makeRandomX() {
       Random random=new Random();
       int x=random.nextInt(681)+100;
       return x;
    }
   public int makeRandomY(){
       Random random=new Random();
       int y=random.nextInt(71)+380;
       return y;
   }

   public GameLauncher(String username){
       game=new Game(username,this);

   }

   public static void changeKey(KeyCode rightKey,KeyCode leftKey,KeyCode upKey,KeyCode downKey){
       RightKey=rightKey;
       LeftKey=leftKey;
       UpKey=upKey;
       DownKey=downKey;

   }


    @Override
    public void start(Stage stage) throws Exception {

        pane = new Pane();
        setSize(pane);
        jet=new Jet(game);
        setScoreLabel(label,"0");
        setNumberRadio(radioActive,"0");
        setCluster(cluster,"0");
        pause(button);
        BackgroundMusic(getClass().getResource("/Media/happy.mp3").toString(),true);
        showWave(WaveNumber,1);
        pane.getChildren().add(progressBar);
        progressBar.setLayoutX(700);
        progressBar.setLayoutY(15);
        progressBar.setPrefSize(80,20);

        createJet();
        pane.getChildren().add(jet);
        pane.setBackground(new Background(createBackgroundImage("/FXML/images/background.jpg")));

        pane.getChildren().add(game.Truck);
        createTruckWave1=new Timeline(new KeyFrame(Duration.seconds(12),actionEvent ->{createTruck();
        truckCount++;
        if(truckCount==5){
            Wave1Finish1=true;
          }
        }));
        createTruckWave1.setCycleCount(5);
        createTruckWave1.play();





        pane.getChildren().add(game.Tank);
        createTank=new Timeline(new KeyFrame(Duration.seconds(10),actionEvent -> {createTank();
        tankCount++;
        if (tankCount==5){
            Wave1Finish2=true;
        }
        }));
        createTank.setCycleCount(5);
        createTank.play();


        pane.getChildren().add(game.Tree);
        createTree=new Timeline(new KeyFrame(Duration.seconds(5),actionEvent -> {
            Tree tree=new Tree(ApplicationController.random.nextDouble(0,makeRandomX()),makeRandomY());
            game.Tree.getChildren().add(tree);
            Timeline removeTimeLine=new Timeline(new KeyFrame(Duration.seconds(4),actionEvent1 -> {
                game.Tree.getChildren().remove(tree);

            }));
            removeTimeLine.play();
        }));
        createTree.setCycleCount(-1);
        createTree.play();


        pane.getChildren().add(game.Building);
        createBuilding=new Timeline(new KeyFrame(Duration.seconds(12),actionEvent -> {
            Building building=new Building(ApplicationController.random.nextDouble(0,makeRandomX()),makeRandomY());
            game.Building.getChildren().add(building);
            Timeline removeTimeLine=new Timeline(new KeyFrame(Duration.seconds(7),actionEvent1 -> {
                game.Building.getChildren().remove(building);
            }));
            removeTimeLine.play();
        }));
        createBuilding.setCycleCount(-1);
        createBuilding.play();


        pane.getChildren().add(game.Fortress);
        createFortress=new Timeline(new KeyFrame(Duration.seconds(9),actionEvent -> {
            Fortress fortress=new Fortress(ApplicationController.random.nextDouble(0,makeRandomX()),makeRandomY());
            game.Fortress.getChildren().add(fortress);
            Timeline removeTimeLine=new Timeline(new KeyFrame(Duration.seconds(6),actionEvent1 -> {
                game.Fortress.getChildren().remove(fortress);
            }));
            removeTimeLine.play();
        }));
        createFortress.setCycleCount(-1);
        createFortress.play();



        Scene scene=new Scene(pane);
        stage.setScene(scene);
        stage.show();
        jet.requestFocus();


    }
    public void createJet() {
       jet=new Jet(game);
       jet.setOnKeyPressed(keyEvent -> {
          if(keyEvent.getCode()==RightKey){
              jet.setX(jet.getX()+15);
              if (jet.getX()>WIDTH){
                  jet.setX(0);
              }
          }else if(keyEvent.getCode()==LeftKey){
              jet.setX(jet.getX()-15);
              if (jet.getX()<0){
                  jet.setX(WIDTH);
              }

          }else if (keyEvent.getCode()==UpKey){
             if((jet.getY()-15)<10){
                 jet.setY(10);
             }else{
                 jet.setY(jet.getY()-15);
             }


          }else if(keyEvent.getCode()==DownKey){
             if(jet.getY()+15>600){
                 jet.setY(600);
             }else{
                 jet.setY(jet.getY()+15);
             }

          } else if (keyEvent.getCode()==SPACE) {
              AllShooting++;
              GameController.shoot(pane,jet,game,false);
              if(!canGoToWave2){CanGoToWave2();
              } else { CanGoToWave3();}

          } else if (keyEvent.getCode()==L) {
              AllShooting++;
              GameController.shootAngle(pane,jet,game,true);
              if(!canGoToWave2){CanGoToWave2();
              } else { CanGoToWave3();}

          } else if(keyEvent.getCode()==R){
              if (NumberOfRadioActive==0){
                  Alert alert=new Alert(Alert.AlertType.WARNING);
                  alert.setTitle("متاسفیم");
                  alert.setContentText("هیچ بمب رادیو اکتیوی نداری!");
                  alert.show();
                  

              }else {
                  NumberOfRadioActive--;
                  setNumberRadio(radioActive, String.valueOf(NumberOfRadioActive));
               GameController.shootRadio(pane,jet,game);
                  AllShooting++;
                  if(!canGoToWave2) {CanGoToWave2();
                  }else{CanGoToWave3();}
               }
                 
          } else if (keyEvent.getCode()==C) {
              if (NumberOfCluster==0){
                  Alert alert=new Alert(Alert.AlertType.WARNING);
                  alert.setTitle("متاسفیم");
                  alert.setContentText("هیچ بمب clusterای نداری!");
                  alert.show();
              }else {
                  NumberOfCluster--;
                  setCluster(cluster, String.valueOf(NumberOfCluster));
                  GameController.shootCluster(pane,jet,game);
                  AllShooting++;
                  if(!canGoToWave2) {
                      CanGoToWave2();
                  }else {CanGoToWave3();}
              }


          } else if (keyEvent.getCode()==T) {
              createTank();

          } else if (keyEvent.getCode()==TAB) {

              if (haveIce){
                  pane.setBackground(new Background(createBackgroundImage("/FXML/images/icee.jpg")));
                  stopAllAnimations();
                   Timeline revertTimeline = new Timeline(new KeyFrame(Duration.seconds(10), event -> {
                       pane.setBackground(new Background(createBackgroundImage("/FXML/images/background.jpg")));
                       resumeAllAnimations();
                  }));
                  revertTimeline.play();




                  progressBar.setProgress(0);
              }

          } else if (keyEvent.getCode()==G) {
              NumberOfRadioActive++;
              setNumberRadio(radioActive, String.valueOf(NumberOfRadioActive));


          } else if (keyEvent.getCode()== CONTROL) {
              NumberOfCluster++;
              setCluster(cluster, String.valueOf(NumberOfCluster));

          } else if (keyEvent.getCode()==P) {
              Wave++;
              showWave(WaveNumber,Wave);
              if (Wave==2){
                     Wave1Finish1=true;
                     Wave1Finish2=true;
                     game.score=1900;
              }else{
                  Wave2Finish1=true;
                  Wave2Finish2=true;
                  Wave2Finish3=true;
                  game.score=4050;
              }

              
          }
       });

    }



    public void setSize(Pane pane){
        pane.setMinHeight(HEIGHT);
        pane.setMaxHeight(HEIGHT);
        pane.setMinWidth(WIDTH);
        pane.setMaxWidth(WIDTH);

    }
    private BackgroundImage createBackgroundImage (String s) {
        Image image = new Image(Game.class.getResource(s).toExternalForm(), WIDTH ,HEIGHT, false, false);
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        return backgroundImage;
    }

    private Truck createTruck() {
        Truck truck = new Truck(ApplicationController.random.nextDouble(0, 100), 450);
        truck.setTruckAnimation(new TruckAnimation(pane, game,truck));
        truck.getTruckAnimation().play();
        game.Truck.getChildren().add(truck);
        this.truck=truck;
        return truck;
    }
    private Tank createTank(){
        Tank tank=new Tank(ApplicationController.random.nextDouble(0,100), 450);
        tank.setTankAnimation(new TankAnimation(pane,game,tank));
        tank.getTankAnimation().play();
        game.Tank.getChildren().add(tank);
        this.tank=tank;
        return tank;

    }

    private AttackTank creatAttackTank(){
       AttackTank attackTank=new AttackTank(ApplicationController.random.nextDouble(0,100),380,game);
       attackTank.setAttackTankAnimation(new AttackTankAnimation(pane,game,attackTank,jet));
       attackTank.getAttackTankAnimation().play();
       game.AttackTank.getChildren().add(attackTank);
       this.attackTank=attackTank;
       return attackTank;
    }

    public static Label label=new Label();
    public static Label radioActive=new Label();
    public static Label cluster=new Label();
    public static Button button=new Button();
    public static Label WaveNumber=new Label();
    public static void setScoreLabel(Label label,String Score){
        label.setText(Score);
        label.setTextFill(Color.WHITE);
        label.setLayoutX(15);
        label.setLayoutY(15);
        if (n==0){
        pane.getChildren().add(label);}
        n=1;
    }
    public static void setNumberRadio(Label radioActive,String number){
        radioActive.setText("R:" +number);
        radioActive.setTextFill(Color.GREY);
        radioActive.setLayoutX(45);
        radioActive.setLayoutY(15);
        if (m==0){
            pane.getChildren().add(radioActive);
        m=1;}

    }
    public static void setCluster(Label cluster,String number){
        cluster.setText("C:"+number);
        cluster.setTextFill(Color.BLUEVIOLET);
        cluster.setLayoutX(75);
        cluster.setLayoutY(15);
        if (p==0){
            pane.getChildren().add(cluster);
            p=1;
        }


    }
    public void pause(Button button){

        button.setText("توقف بازی");
        button.setTextFill(Color.SNOW);
        button.setLayoutX(700);
        button.setLayoutY(40);
        button.setOnAction(actionEvent -> {
            stopAllAnimations();
            Stage newStage = new Stage();
            VBox vbox = new VBox();
            Label label = new Label("تنظیمات");
            CheckBox mute = new CheckBox("توقف موسیقی");
            mute.setOnAction(actionEvent1 -> {
                if (!GameIsMuted){
                if (mute.isSelected()){
                    BackgroundMusic(getClass().getResource("/Media/Noor.mp3").toString(),false);
                }}
            });
            Button exit=new Button("خروج");
            exit.setOnAction(actionEvent1 -> {
                GameMenu gameMenu=new GameMenu();
                try {
                    gameMenu.start(MainMenu.stage);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                if (!GameIsMuted){
                BackgroundMusic(getClass().getResource("/Media/Noor.mp3").toString(),false);}
            });
            Button help=new Button("راهنمای بازی");
            help.setOnAction(actionEvent1 -> {
                Stage newStage2 = new Stage();
                VBox vbox2 = new VBox();
                Label label2 = new Label("راهنمای بازی");
                Label label3=new Label("با فشردن دکمه هواپیما W به بالا حرکت میکند. \n" +
                        "با فشردن دکمه Z هواپیما به پایین حرکت میکند.\n" +
                        "با فشردن دکمه A هواپیما به چپ حرکت میکند.\n" +
                        "با فشردن دکمه S هواپیما به راست حرکت میکند.\n" +
                        "با فشردن Tab میتوانید از حالت یخ زده استفاده کنید\n"+
                        "با فشردن Space میتوانید بمب معمولی شلیک کنید\n"+
                        "با فشردن R میتوانید بمب رادیواکتیو شلیک کنید.\n"+
                        "با فشردن c میتوانید بمب کلاستر شلیک کنید \n"
                );



                vbox2.getChildren().addAll(label2,label3);
                Scene scene2 = new Scene(vbox2, 400, 300);
                newStage2.setScene(scene2);
                newStage2.show();

            });

            CheckBox checkbox1 =new CheckBox("آهنگ اول");
            CheckBox checkbox2 =new CheckBox("آهنگ دوم");
            CheckBox checkbox3 =new CheckBox("آهنگ سوم");
            CheckBox checkbox4 =new CheckBox("آهنگ چهارم");
            if (!GameIsMuted) {
                checkbox1.setOnAction(actionEvent1 -> {
                    if (checkbox1.isSelected()) {
                        BackgroundMusic(getClass().getResource("/Media/Noor.mp3").toString(), true);
                    }
                });
                checkbox2.setOnAction(actionEvent2 -> {
                    if (checkbox2.isSelected()) {
                        BackgroundMusic(getClass().getResource("/Media/dark-forest.mp3").toString(), true);
                    }
                });
                checkbox3.setOnAction(actionEvent3 -> {
                    if (checkbox3.isSelected()) {
                        BackgroundMusic(getClass().getResource("/Media/Epic-Chase.mp3").toString(), true);
                    }
                });
                checkbox4.setOnAction(actionEvent4 -> {
                    if (checkbox4.isSelected()) {
                        BackgroundMusic(getClass().getResource("/Media/happy.mp3").toString(), true);
                    }
                });
            }


            vbox.getChildren().addAll(label, button,exit,mute,help,checkbox1,checkbox2,checkbox3,checkbox4);
            Scene scene = new Scene(vbox, 400, 300);
            newStage.setScene(scene);
            newStage.show();

        });
        pane.getChildren().add(button);

    }

    private void stopAllAnimations(){
            if (pane.getChildren().contains(tank)) {tank.getTankAnimation().stop();}
            createTank.stop();
            if (pane.getChildren().contains(truck)) {truck.getTruckAnimation().stop();}
            if (pane.getChildren().contains(attackTank)) {attackTank.getAttackTankAnimation().stop();}
            createTruckWave1.stop();
            createTree.stop();
            createFortress.stop();
            createBuilding.stop();
    }
    private void resumeAllAnimations(){
            if (pane.getChildren().contains(tank)) {tank.getTankAnimation().play();}
            createTank.play();
            if (pane.getChildren().contains(truck)) {truck.getTruckAnimation().play();}
            if (pane.getChildren().contains(attackTank)){
                attackTank.getAttackTankAnimation().play();}
            createTruckWave1.play();
            createBuilding.play();
            createTree.play();
            createFortress.play();

    }
    public static void BackgroundMusic(String address, boolean play){
        if (currentMediaPlayer != null) {
            currentMediaPlayer.stop();
        }
        Media media=new Media(address);
        MediaPlayer mediaPlayer=new MediaPlayer(media);
        mediaPlayer.setAutoPlay(true);
        mediaPlayer.setOnEndOfMedia(() -> mediaPlayer.seek(Duration.ZERO));
        if (!play){
            mediaPlayer.stop();
        } else {
            currentMediaPlayer = mediaPlayer;
        }


    }
    public  void CanGoToWave2(){
        if (Wave1Finish1 && Wave1Finish2 && game.score>=1800){
            Wave=2;
            Stage newStage = new Stage();
            VBox vbox = new VBox();
            Label label = new Label("اتمام Wave1 ");
            Label label2=new Label("accuracy: "+ (double)succesfullShooting/AllShooting);
            vbox.getChildren().addAll(label,label2);
            Scene scene = new Scene(vbox, 400, 300);
            newStage.setScene(scene);
            newStage.show();
            showWave(WaveNumber,2);
            canGoToWave2=true;
            Wave2TankAndTruck();

        }
    }
    public void CanGoToWave3(){
        if (Wave2Finish1 && Wave2Finish2 && Wave2Finish3 && game.score>=4000) {
            Wave=3;
            Stage newStage = new Stage();
            VBox vbox = new VBox();
            Label label = new Label("اتمام Wave2 ");
            Label label2=new Label("accuracy: "+ (double)succesfullShooting/AllShooting);
            vbox.getChildren().addAll(label,label2);
            Scene scene = new Scene(vbox, 400, 300);
            newStage.setScene(scene);
            newStage.show();
            showWave(WaveNumber,3);


        }
    }

    public static void showWave(Label label,int number){
        label.setText(String.valueOf(number));
        label.setTextFill(Color.WHITE);
        label.setLayoutX(400);
        label.setLayoutY(15);
        if (q==0){
            pane.getChildren().add(label);}
        q=1;
    }
    public void Wave2TankAndTruck(){
        if(flag==0){
        truckCount=0;
        tankCount=0;
        createTruckWave2=new Timeline(new KeyFrame(Duration.seconds(12),actionEvent ->{createTruck();
            truckCount++;
            if(truckCount==5){
                Wave2Finish1=true;
            }
        }));
        createTruckWave2.setCycleCount(5);
        createTruckWave2.play();

        createTankWave2=new Timeline(new KeyFrame(Duration.seconds(10),actionEvent -> {createTank();
         tankCount++;
        if(tankCount==5){
        Wave2Finish2=true;}
        }));
        createTankWave2.setCycleCount(5);
        createTankWave2.play();

        pane.getChildren().add(game.AttackTank);
        createAttackTank=new Timeline(new KeyFrame(Duration.seconds(20),actionEvent -> {creatAttackTank();

        AttackTankCount++;
        if (AttackTankCount==4){
        Wave2Finish3=true;}
        }));
        createAttackTank.setCycleCount(4);
        createAttackTank.play();
        flag=1;}
    }
    public static void GameOver(){
        BackgroundMusic(GameLauncher.class.getResource("/Media/Noor.mp3").toString(),false);
        Stage newStage = new Stage();
        VBox vbox = new VBox();
        Label label2=new Label("accuracy: "+ (double)succesfullShooting/AllShooting);
        Label lable3=new Label("you lose in Wave:" + Wave);
        Label label4=new Label("your score is:"+ game.score);
        Button button1=new Button("بازگشت به منوی اصلی");
        button1.setOnAction(actionEvent -> {
            GameMenu gameMenu=new GameMenu();
            try {
                gameMenu.start(MainMenu.stage);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        Image image = new Image(Game.class.getResource("/FXML/images/gameOver.jpg").toExternalForm(), 400 ,300, false, false);
        BackgroundImage backgroundImage = new BackgroundImage(image, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        Background background = new Background(backgroundImage);
        vbox.setBackground(background);
        vbox.getChildren().addAll(label2,lable3,label4,button1);
        Scene scene = new Scene(vbox, 400, 300);
        newStage.setScene(scene);
        newStage.show();


    }


}