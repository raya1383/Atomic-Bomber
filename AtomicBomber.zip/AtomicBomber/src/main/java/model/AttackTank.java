package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import view.Animation.AttackTankAnimation;
import view.Animation.TankAnimation;

public class AttackTank extends Rectangle {
    public final double WIDTH = 100;
    public final double HEIGHT = 100;
    public final Game game;
    public boolean isHit = false;
    private AttackTankAnimation attackTankAnimation;

    public AttackTankAnimation getAttackTankAnimation() {
        return attackTankAnimation;
    }
    public void setAttackTankAnimation(AttackTankAnimation attackTankAnimation){
        this.attackTankAnimation=attackTankAnimation;
    }

    public AttackTank(double x, double y,Game game){
        super(x,y,100,100);
        this.game=game;
        this.setFill(new ImagePattern(new Image
                (Truck.class.getResource("/FXML/images/AttackTank.png").toExternalForm())));

    }
}
