package model;


import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import view.Animation.TankAnimation;

public class Tank extends Rectangle {
    public final double WIDTH = 50;
    public final double HEIGHT = 50;
    public boolean isHit = false;
    private TankAnimation tankAnimation ;

    public TankAnimation getTankAnimation() {
        return tankAnimation;
    }
    public void setTankAnimation(TankAnimation tankAnimation){
        this.tankAnimation=tankAnimation;
    }

    public Tank(double x, double y){
        super(x,y,50,50);
        this.setFill(new ImagePattern(new Image
                (Truck.class.getResource("/FXML/images/Tank.png").toExternalForm())));

    }


}
