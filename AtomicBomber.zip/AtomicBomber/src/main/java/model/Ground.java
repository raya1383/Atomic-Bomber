package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Ground extends Rectangle {
    public double x;
    public double y;
    public static int Width=20;
    public static int High=20;
    public Ground(double x,double y){
        super(20,20);
        this.setFill(new ImagePattern(
                new Image(Ground.class.getResource("/FXML/images/fire-1.png").toString())

        ));
    }
}
