package model;

import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Cluster extends Rectangle {
    public double Width=30;
    public double High=30;
    public Cluster(Jet jet){
        super(50,50);
        setX(jet.getX()+jet.WIDTH/2-Width/2+15);
        setY(jet.getY()+70);
        this.setFill(new ImagePattern(new Image(Bombs.class.getResource("/FXML/images/cluster.png").toExternalForm())));
    }
}
