package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Bombs extends Rectangle {
    public final double WIDTH=15;
    public final double HEIGHT=15;
    public Bombs(Jet jet){
       super(15,15);
       setX(jet.getX()+jet.WIDTH/2-WIDTH/2+15);
       setY(jet.getY()+70);
       this.setFill(new ImagePattern(new Image(Bombs.class.getResource("/FXML/images/bomb.png").toExternalForm())));

    }

}
