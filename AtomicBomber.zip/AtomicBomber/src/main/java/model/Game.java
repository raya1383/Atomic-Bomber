package model;

import javafx.animation.Transition;
import javafx.scene.Group;
import view.GameLauncher;

import java.util.ArrayList;

public class Game {
    public final int WIDTH=800;
    public final double HEIGHT=500;
    public String username;
    public int score=0;
    public final Group Truck=new Group();
    public final Group Tank=new Group();
    public final Group AttackTank=new Group();
    public final Group Tree=new Group();
    public final Group Jet=new Group();
    public final Group Building=new Group();
    public final Group Fortress=new Group();
    public final Group Ground=new Group();
    public GameLauncher gameLauncher;
    public final Group Trucks = new Group();
    public final ArrayList<Transition> animations = new ArrayList<>();

    public Game(String username, GameLauncher gameLauncher){
        this.username=username;
        this.gameLauncher = gameLauncher;
    }

}
