package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Building extends Rectangle {
    public final double WIDTH = 60;
    public final double HEIGHT = 60;
    public boolean isHit = false;
    public Building(double x, double y){
        super(x,y,50,50);
        this.setFill(new ImagePattern(new Image
                (Truck.class.getResource("/FXML/images/building.png").toExternalForm())));

    }

}
