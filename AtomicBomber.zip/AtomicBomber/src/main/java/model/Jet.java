package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Jet extends Rectangle {
    int x,y;
    public final double WIDTH=100;
    public final double HEIGHT=100;
    public final Game game;
    public final boolean isHit=false;
    public Jet(Game game){
        super(150,150);
        this.game=game;
        setFill(new ImagePattern(new Image(Jet.class.getResource("/FXML/images/jet.png").toExternalForm())));
    }
    public void setup(){
        x=400;
        y=400;
    }

    public void draw(){

    }

}
